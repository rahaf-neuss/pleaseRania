module.exports = {

"[project]/src/components/forms/flow-meter.tsx [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
// 'use client';
// import { useEffect, useState } from 'react';
// import { FormProvider, useForm } from 'react-hook-form';
// import { zodResolver } from '@hookform/resolvers/zod';
// import { motion, AnimatePresence } from 'framer-motion';
// import { Button } from '@/components/ui/button';
// import { Progress } from '@/components/ui/progress';
// import { Toaster } from '@/components/ui/toaster';
// import { useToast } from '@/components/ui/use-toast';
// import { StepOne } from './step-one';
// import { StepTwo } from './step-two';
// import { StepThree } from './step-three';
// import { StepFour } from './step-four';
// import { RfpSchema, RfpFormData, defaultRfpFormData } from '@/../schema/rfp-schema';
// import { Stepper, StepperItem, StepperSeparator, StepperTrigger, StepperIndicator } from '@/components/ui/stepper';
// import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
// import { Separator } from '@/components/ui/separator';
// import { X } from 'lucide-react';
// interface FlowMeterFormWizardProps { id?: string; }
// interface GraphPreviewProps { onClose: () => void; data: RfpFormData; }
// const stepTitles = [
//   'Basic Information',
//   'General Info',
//   'Location & Measurement',
//   'Monitoring Details',
//   'Preview & Submit',
// ];
// export const GraphPreview = ({ onClose, data }: GraphPreviewProps) => {
//   const formatDate = (dateString: string | Date | undefined) => {
//     if (!dateString) return 'Not specified';
//     return new Date(dateString).toLocaleDateString();
//   };
//   const renderTextItem = (label: string, value: string | number | undefined) => (
//     <div>
//       <p className="text-xs font-semibold text-muted-foreground">{label}</p>
//       <p className="text-sm">{value || 'Not specified'}</p>
//     </div>
//   );
//   return (
//     <motion.div
//       initial={{ opacity: 0, x: 50 }}
//       animate={{ opacity: 1, x: 0 }}
//       exit={{ opacity: 0, x: 50 }}
//       transition={{ duration: 0.4 }}
//       className="bg-white rounded-xl shadow-md p-6 h-fit sticky top-6 relative space-y-6 w-[300px]"
//     >
//       <button
//         onClick={onClose}
//         title="Hide insights"
//         className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"
//       >
//         <X size={18} />
//       </button>
//       <h3 className="text-lg font-semibold mb-2">📋 Form Preview</h3>
//       <Separator />
//       <div className="space-y-4">
//         {renderTextItem('Item', data.item)}
//         {renderTextItem('Type of RFP', data.typeOfRfp)}
//         {renderTextItem('RFP Reference', data.rfpReference)}
//         {renderTextItem('Licensee', data.generalInfo?.licensee)}
//         {renderTextItem('Contact Number', data.generalInfo?.contactNumber)}
//         {renderTextItem('Flow Option', data.flowMeasurement?.selectedOption || 'None selected')}
//         {renderTextItem('Install Date', formatDate(data.flowMonitoring?.installation?.meterInstallDate))}
//         {renderTextItem('Removal Date', formatDate(data.flowMonitoring?.installation?.meterRemovalDate))}
//       </div>
//     </motion.div>
//   );
// };
// export default function FlowMeterFormWizard({ id }: FlowMeterFormWizardProps) {
//   const { toast } = useToast();
//   const [currentStep, setCurrentStep] = useState(1);
//   const [showGraph, setShowGraph] = useState(true);
//   const steps = [1, 2, 3, 4];
//   const methods = useForm<RfpFormData>({
//     resolver: zodResolver(RfpSchema),
//     mode: 'onBlur',
//     defaultValues: defaultRfpFormData,
//   });
//   const liveData = methods.watch();
//   const handleNextStep = () => setCurrentStep((s) => Math.min(s + 1, steps.length));
//   const handlePrevStep = () => currentStep > 1 && setCurrentStep((s) => s - 1);
//   const saveDraft = () => {
//     const data = methods.getValues();
//     localStorage.setItem('rfpDraft', JSON.stringify(data));
//     toast({ title: 'Draft Saved', description: 'You can continue later' });
//   };
//   const resetWithConfirm = () => {
//     if (confirm('Are you sure you want to reset the form?')) {
//       methods.reset(defaultRfpFormData);
//       localStorage.removeItem('rfpDraft');
//       setCurrentStep(1);
//     }
//   };
//   useEffect(() => {
//     const subscription = methods.watch(() => {
//       const draft = methods.getValues();
//       localStorage.setItem('rfpDraft', JSON.stringify(draft));
//     });
//     return () => subscription.unsubscribe();
//   }, [methods]);
//   const renderStepContent = () => {
//     switch (currentStep) {
//       case 1: return <StepOne />;
//       case 2: return <StepTwo />;
//       case 3: return <StepThree />;
//       case 4: return <StepFour />;
//     }
//   };
//   return (
//     <>
//       <Toaster />
//       <FormProvider {...methods}>
//         <section className="bg-gradient-to-b from-white to-muted/40 py-12 min-h-screen">
//           <div className="w-full px-4 md:px-8 lg:px-16 grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-10">
//             <div>
//               <form
//                 onSubmit={methods.handleSubmit((data) => {
//                   console.log('✅ Final Submitted Data:', data);
//                   toast({ title: 'Success!', description: 'Data logged to console.' });
//                 }, (errors) => {
//                   toast({ title: '⚠️ Validation Failed', description: '', variant: 'destructive' });
//                   console.error('❌ Validation Errors:', errors);
//                 })}
//                 className="bg-white rounded-2xl shadow-xl p-6 md:p-10 space-y-10"
//               >
//                 <div className="text-center space-y-1">
//                   <h1 className="text-3xl font-bold tracking-tight">
//                     {id ? 'Edit Flow Meter RFP' : 'Create New Flow Meter RFP'}
//                   </h1>
//                   <p className="text-muted-foreground text-sm">{stepTitles[currentStep - 1]}</p>
//                 </div>
//                 <Progress value={(currentStep / steps.length) * 100} className="mb-4" title="Form Progress" />
//                 <Stepper value={currentStep} onValueChange={setCurrentStep} className="w-full bg-muted/60 rounded-lg p-3 shadow">
//                   {steps.map((step) => (
//                     <StepperItem key={step} step={step} className="flex-1">
//                       <TooltipProvider>
//                         <Tooltip>
//                           <TooltipTrigger asChild>
//                             <StepperTrigger className="w-full" onClick={() => setCurrentStep(step)}>
//                               <StepperIndicator />
//                             </StepperTrigger>
//                           </TooltipTrigger>
//                           <TooltipContent>
//                             Step {step}: {stepTitles[step - 1]}
//                           </TooltipContent>
//                         </Tooltip>
//                       </TooltipProvider>
//                       {step < steps.length && <StepperSeparator />}
//                     </StepperItem>
//                   ))}
//                 </Stepper>
//                 <AnimatePresence mode="wait">
//                   <motion.div
//                     key={currentStep}
//                     initial={{ opacity: 0, x: 20 }}
//                     animate={{ opacity: 1, x: 0 }}
//                     exit={{ opacity: 0, x: -20 }}
//                     transition={{ duration: 0.3 }}
//                     className="bg-muted/50 border p-6 rounded-lg shadow-sm"
//                   >
//                     {renderStepContent()}
//                   </motion.div>
//                 </AnimatePresence>
//                 <div className="flex flex-col sm:flex-row justify-between pt-4 gap-4">
//                   <Button type="button" variant="outline" onClick={handlePrevStep} disabled={currentStep === 1} className="sm:w-32">Previous</Button>
//                   <div className="flex flex-wrap gap-2 justify-end">
//                     {!showGraph && (
//                       <Button variant="outline" onClick={() => setShowGraph(true)} className="w-32">
//                         Show Panel
//                       </Button>
//                     )}
//                     <Button type="button" variant="ghost" onClick={saveDraft} className="w-32">Save Draft</Button>
//                     <Button type="button" variant="ghost" onClick={resetWithConfirm} className="w-32">Reset</Button>
//                     {currentStep < steps.length ? (
//                       <Button type="button" onClick={handleNextStep} className="w-32">Next</Button>
//                     ) : (
//                       <Button type="submit" className="w-36">Submit Final</Button>
//                     )}
//                   </div>
//                 </div>
//               </form>
//             </div>
//             {showGraph && <GraphPreview onClose={() => setShowGraph(false)} data={liveData} />}
//           </div>
//         </section>
//       </FormProvider>
//     </>
//   );
// }
// 'use client';
// import { useEffect, useState } from 'react';
// import { FormProvider, useForm } from 'react-hook-form';
// import { zodResolver } from '@hookform/resolvers/zod';
// import { Button } from '@/components/ui/button';
// import { useToast } from '@/components/ui/use-toast';
// import { Toaster } from '@/components/ui/toaster';
// import { RfpSchema, RfpFormData, defaultRfpFormData } from '@/../schema/rfp-schema';
// import { motion, AnimatePresence } from 'framer-motion';
// import { Progress } from '@/components/ui/progress';
// import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
// import { X, Eye } from 'lucide-react';
// import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
// import { StepOne } from './step-one';
// import { StepTwo } from './step-two';
// import { StepThree } from './step-three';
// import { StepFour } from './step-four';
// // import { StepFivePreview } from './step-five';
// import {
//   Stepper,
//   StepperIndicator,
//   StepperItem,
//   StepperSeparator,
//   StepperTrigger,
// } from '@/components/ui/stepper';
// interface FlowMeterFormWizardProps {
//   id?: string;
// }
// const stepTitles = [
//   'Basic Information',
//   'General Info',
//   'Location & Measurement',
//   'Monitoring Details',
//   'Preview & Submit',
// ];
// const GraphPreview = ({ onClose }: { onClose: () => void }) => (
//   <div className="bg-white rounded-xl shadow-md p-6 h-fit sticky top-6 relative">
//     <button
//       onClick={onClose}
//       title="Hide insights"
//       className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"
//     >
//       <X size={18} />
//     </button>
//     <h3 className="text-lg font-semibold mb-3">📊 Quick Insights</h3>
//     <p className="text-sm text-muted-foreground mb-2">
//       This panel can show a live data preview, a chart summary, or helpful insights while filling the form.
//     </p>
//     <div className="w-full h-32 bg-muted rounded-lg flex items-center justify-center text-muted-foreground text-xs">
//       Placeholder for graph / summary
//     </div>
//   </div>
// );
// export default function FlowMeterFormWizard({ id }: FlowMeterFormWizardProps) {
//   const { toast } = useToast();
//   const [isSummaryOpen, setIsSummaryOpen] = useState(false);
//   const [currentStep, setCurrentStep] = useState(1);
//   const [showGraph, setShowGraph] = useState(true);
//   const steps = [1, 2, 3, 4];
//   const methods = useForm({
//     resolver: zodResolver(RfpSchema),
//     mode: 'onBlur',
//     defaultValues: defaultRfpFormData,
//   });
//   const handleFinalSubmit = async (data: RfpFormData) => {
//     try {
//       // Check that licensee is present
//       if (!data.generalInfo?.licensee) {
//         toast({
//           title: '❌ Missing Licensee',
//           description: 'Please provide a licensee.',
//           variant: 'destructive',
//         });
//         return;
//       }
//       const safeCreate = <T extends Record<string, unknown>>(obj?: T): { create: T } | undefined => {
//         if (!obj || typeof obj !== 'object') return undefined;
//         const hasValidValues = Object.values(obj).some(
//           (v) =>
//             v !== undefined &&
//             v !== '' &&
//             !(Array.isArray(v) && v.length === 0) &&
//             !(typeof v === 'object' && v !== null && Object.keys(v).length === 0)
//         );
//         return hasValidValues ? { create: obj } : undefined;
//       };
//       const payload = {
//         typeOfRfp: data.typeOfRfp,
//         RfpReference: data.rfpReference,
//         startDate: data.startDate || undefined,
//         completionDate: data.completionDate || undefined,
//         panelMeetingDate: data.panelMeetingDate || undefined,
//         panelDecisionDate: data.panelDecisionDate || undefined,
//         LocationType: data.locationType?.type?.trim()
//           ? { create: { type: data.locationType.type.trim() } }
//           : undefined,
//           generalInfo: {
//             create: {
//               ...Object.fromEntries(
//                 Object.entries(data.generalInfo || {}).filter(
//                   ([ v]) => v !== '' && v !== undefined && v !== null
//                 )
//               ),
//               reportDate:
//                 data.generalInfo?.reportDate instanceof Date
//                   ? data.generalInfo.reportDate.toISOString()
//                   : data.generalInfo?.reportDate,
//             },
//           },
//         location: safeCreate(data.location),
//         flowMeasurement: safeCreate(data.flowMeasurement),
//         flowRegister: {
//           create: {
//             inventory: safeCreate(data.flowMonitoring?.inventory)?.create || undefined,
//             installation: safeCreate({
//               ...data.flowMonitoring?.installation,
//               meterInstallDate: data.flowMonitoring?.installation?.meterInstallDate || undefined,
//               meterRemovalDate: data.flowMonitoring?.installation?.meterRemovalDate || undefined,
//             })?.create,
//             maintenance: safeCreate(data.flowMonitoring?.maintenance)?.create || undefined,
//           },
//         },
//         data: safeCreate(data.data),
//         maf: safeCreate(data.maf),
//         attachments:
//           Array.isArray(data.attachments) && data.attachments.length > 0
//             ? {
//                 create: data.attachments
//                   .filter((a) => a.type && a.filePath)
//                   .map((a) => ({
//                     type: a.type,
//                     filePath: a.filePath,
//                     uploadedAt: a.uploadedAt ?? new Date().toISOString(),
//                   })),
//               }
//             : undefined,
//       };
//       console.log('🔥 Payload being submitted:', JSON.stringify(payload, null, 2));
//       const res = await fetch(
//         `${process.env.NEXT_PUBLIC_API_URL}/api/rfp${id ? `/${id}` : '/create'}`,
//         {
//           method: id ? 'PUT' : 'POST',
//           headers: { 'Content-Type': 'application/json' },
//           credentials: 'include',
//           body: JSON.stringify(payload),
//         }
//       );
//       const resData = await res.json();
//       if (!res.ok) throw new Error(resData.error || 'Failed to submit');
//       toast({
//         title: '✅ Submitted!',
//         description: 'RFP has been successfully submitted.',
//       });
//       methods.reset(defaultRfpFormData);
//       localStorage.removeItem('rfpDraft');
//       setCurrentStep(1);
//     } catch (err) {
//       const message = err instanceof Error ? err.message : 'An unknown error occurred.';
//       toast({ title: '❌ Submission Error', description: message, variant: 'destructive' });
//     }
//   };
//   const handleNextStep = () => setCurrentStep((s) => Math.min(s + 1, steps.length));
//   const handlePrevStep = () => currentStep > 1 && setCurrentStep((s) => s - 1);
//   const saveDraft = () => {
//     const data = methods.getValues();
//     localStorage.setItem('rfpDraft', JSON.stringify(data));
//     toast({ title: 'Draft Saved', description: 'You can continue later' });
//   };
//   const resetWithConfirm = () => {
//     if (confirm('Are you sure you want to reset the form?')) {
//       methods.reset(defaultRfpFormData);
//       localStorage.removeItem('rfpDraft');
//       setCurrentStep(1);
//     }
//   };
//   useEffect(() => {
//     const subscription = methods.watch(() => {
//       const draft = methods.getValues();
//       localStorage.setItem('rfpDraft', JSON.stringify(draft));
//     });
//     return () => subscription.unsubscribe();
//   }, [methods]);
//   const renderStepContent = () => {
//     switch (currentStep) {
//       case 1:
//         return <StepOne />;
//       case 2:
//         return <StepTwo />;
//       case 3:
//         return <StepThree />;
//       case 4:
//         return <StepFour />;
//       // case 5:
//       //   return <StepFivePreview data={methods.getValues() as RfpFormData} />;
//       default:
//         return null;
//     }
//   };
//   return (
//     <>
//       <Toaster />
//       <FormProvider {...methods}>
//         <section className="bg-gradient-to-b from-white to-muted/40 py-12 min-h-screen">
//           <div className="w-full px-4 md:px-8 lg:px-16 grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-10">
//             <div>
//               <form
//                 onSubmit={methods.handleSubmit(handleFinalSubmit, (errors) => {
//                   toast({
//                     title: '⚠️ Validation Failed',
//                     description: 'Please fix the errors before submitting.',
//                     variant: 'destructive',
//                   });
//                   console.error('Validation errors:', errors);
//                 })}
//                 className="bg-white rounded-2xl shadow-xl p-6 md:p-10 space-y-10"
//               >
//                 <div className="text-center space-y-1">
//                   <h1 className="text-3xl font-bold tracking-tight">
//                     {id ? 'Edit Flow Meter RFP' : 'Create New Flow Meter RFP'}
//                   </h1>
//                   <p className="text-muted-foreground text-sm">
//                     {stepTitles[currentStep - 1]}
//                   </p>
//                 </div>
//                 <Progress
//                   value={(currentStep / steps.length) * 100}
//                   className="mb-4"
//                   title="Form Progress"
//                 />
//                 <Stepper
//                   value={currentStep}
//                   onValueChange={setCurrentStep}
//                   className="w-full bg-muted/60 rounded-lg p-3 shadow"
//                 >
//                   {steps.map((step) => (
//                     <StepperItem key={step} step={step} className="flex-1">
//                       <TooltipProvider>
//                         <Tooltip>
//                           <TooltipTrigger asChild>
//                             <StepperTrigger className="w-full">
//                               <StepperIndicator />
//                             </StepperTrigger>
//                           </TooltipTrigger>
//                           <TooltipContent>
//                             Step {step}: {stepTitles[step - 1]}
//                           </TooltipContent>
//                         </Tooltip>
//                       </TooltipProvider>
//                       {step < steps.length && <StepperSeparator />}
//                     </StepperItem>
//                   ))}
//                 </Stepper>
//                 <AnimatePresence mode="wait">
//                   <motion.div
//                     key={currentStep}
//                     initial={{ opacity: 0, x: 20 }}
//                     animate={{ opacity: 1, x: 0 }}
//                     exit={{ opacity: 0, x: -20 }}
//                     transition={{ duration: 0.3 }}
//                     className="bg-muted/50 border p-6 rounded-lg shadow-sm"
//                   >
//                     {renderStepContent()}
//                   </motion.div>
//                 </AnimatePresence>
//                 <div className="flex flex-col sm:flex-row justify-between pt-4 gap-4">
//                   <Button
//                     type="button"
//                     variant="outline"
//                     onClick={handlePrevStep}
//                     disabled={currentStep === 1}
//                     className="sm:w-32"
//                   >
//                     Previous
//                   </Button>
//                   <div className="flex flex-wrap gap-2 justify-end">
//                     {!showGraph && (
//                       <Button variant="outline" onClick={() => setShowGraph(true)} className="w-32">
//                         <Eye size={16} className="mr-2" /> Show Panel
//                       </Button>
//                     )}
//                     <Button type="button" variant="ghost" onClick={saveDraft} className="w-32">
//                       Save Draft
//                     </Button>
//                     <Button type="button" variant="ghost" onClick={resetWithConfirm} className="w-32">
//                       Reset
//                     </Button>
//                     {currentStep < steps.length ? (
//                       <Button type="button" onClick={handleNextStep} className="w-32">
//                         Next
//                       </Button>
//                     ) : (
//                       <Button type="submit" className="w-36">
//                         Submit Final
//                       </Button>
//                     )}
//                   </div>
//                 </div>
//               </form>
//             </div>
//             {showGraph && <GraphPreview onClose={() => setShowGraph(false)} />}
//           </div>
//         </section>
//         <Dialog open={isSummaryOpen} onOpenChange={setIsSummaryOpen}>
//           <DialogContent className="max-w-2xl">
//             <DialogHeader>
//               <DialogTitle>Review Submission</DialogTitle>
//             </DialogHeader>
//             {/* <StepFivePreview data={methods.getValues() as RfpFormData} /> */}
//             <div className="text-sm text-destructive mt-4">
//               {Object.keys(methods.formState.errors).length > 0 &&
//                 '⚠️ Please fix validation errors before final submission.'}
//             </div>
//             <DialogFooter>
//               <Button onClick={() => setIsSummaryOpen(false)} variant="ghost">
//                 Cancel
//               </Button>
//             </DialogFooter>
//           </DialogContent>
//         </Dialog>
//       </FormProvider>
//     </>
//   );
// }
}}),
"[project]/src/app/dashboard/flow-meter-form/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>FlowMeterFormPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$forms$2f$flow$2d$meter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/forms/flow-meter.tsx [app-ssr] (ecmascript)");
'use client';
;
;
function FlowMeterFormPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-6 space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-semibold",
                children: "Add Flow Meter"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/flow-meter-form/page.tsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$forms$2f$flow$2d$meter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/dashboard/flow-meter-form/page.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/flow-meter-form/page.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=src_854a2414._.js.map