module.exports = {

"[project]/src/app/dashboard/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
v;
}}),

};

//# sourceMappingURL=src_app_dashboard_layout_tsx_dce8d85c._.js.map